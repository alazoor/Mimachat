package com.arabic.aitoolkit.core.embedding;

public class ImagePreprocessor {
	
}