package com.arabic.aitoolkit.core.search;

public class TextWitjVector {
	
}