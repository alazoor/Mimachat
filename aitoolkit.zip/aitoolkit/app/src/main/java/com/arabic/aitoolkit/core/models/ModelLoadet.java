package com.arabic.aitoolkit.core.models;

public class ModelLoadet {
	
}